# VFN-IF
## How to install uni-core
```shell
cd Uni-Core
python setup.py install --build
```

## Data Processed
We've provided the processed data on the [Zenodo](https://zenodo.org/records/11369361) platform. You can download the data from the link provided and put it as `processed` in the root directory.