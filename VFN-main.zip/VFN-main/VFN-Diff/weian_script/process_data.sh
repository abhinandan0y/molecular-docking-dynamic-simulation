python data/process_pdb_dataset.py \
    --mmcif_dir /media/nvme/dataset/protein/alphafold/pdb_mmcif \
    --write_dir /mnt/nas/share2/home/wayne/dataset/se3