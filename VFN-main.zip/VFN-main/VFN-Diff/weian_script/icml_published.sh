python experiments/train_se3_diffusion.py --config-name=icml_published
