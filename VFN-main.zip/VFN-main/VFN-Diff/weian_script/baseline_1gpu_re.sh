python experiments/train_se3_diffusion.py --config-name=baseline_1gpu_re
